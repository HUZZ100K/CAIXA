-- server.lua
print("Server iniciado")