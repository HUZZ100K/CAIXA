-- client.lua
print("Client iniciado")